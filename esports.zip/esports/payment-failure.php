<?php include_once "header.inc.php";
?>

<main id="main">



  <!-- ======= Features Section ======= -->
    <section id="features" class="features">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Payment</h2>
            </div>
            <br><br><br><br><br>
            <center data-aos="fade-up">
        <p>Sorry. We couldn't process your transaction</p>
        <div class="btn-wrap">
            <a href="account-info.php" class="btn-buy">Go to your account</a>            </div>


    </div>
  </section><!-- End Features Section -->
</center>

<br>
<br>
<br>
<br>
<br>

</main><!-- End #main -->

<?php include_once "footer.inc.php" ?>
