<div id="admin-sidebar" class="col-md-2 p-x-0 p-y-3">
       <ul class="sidenav admin-sidenav list-unstyled">
           <li><a href="index.php">HOME</a></li>
           <li><a href="coaches.php">COACHES</a></li>
           <li><a href="champs.php">CHAMPIONS</a></li>
           <li><a href="stats.php">STATISTICS</a></li>
           <li><a href="news.php">NEWS/ARTICLES</a></li>
           <li><a href="about.php">ABOUT</a></li>
       </ul>
   </div> <!-- /#admin-sidebar -->
