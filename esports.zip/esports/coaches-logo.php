
    <!-- ======= Clients Section ======= -->
    <section id="clients" class="clients clients">
      <div class="container">

        <div class="row">

          <div class="col-lg-2 col-md-4 col-6">
            <a href="coaches.php"><img src="assets/img/dota-logo.png" class="img-fluid" alt="" data-aos="zoom-in"></a>
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <a href="coaches-lol.php"><img src="assets/img/lol-logo.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="100"></a>
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <a href="coaches-pubg.php"><img src="assets/img/pubg-logo.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="200"></a>
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <a href="coaches-csgo.php"><img src="assets/img/csgo-logo.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="300"></a>
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <a href="coaches-fornite.php"><img src="assets/img/fortnite-logo.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="400"></a>
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <a href="coaches-heartstone.php"><img src="assets/img/heartstone-logo.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="500"></a>
          </div>

        </div>

      </div>
    </section><!-- End Clients Section -->
